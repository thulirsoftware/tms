@extends('theme.default')

@section('content')
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Employees</h1>
    </div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div style="text-align: right">
<a href="{{url('Admin/Employee/create')}}" class="btn btn-info btn-circle"><i class="fa fa-user-plus"></i></a>
</div>
<table class="table table-striped table-bordered table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Designation</th>
            <th>Mobile</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
    @foreach($employees as $employee)
        <tr>
            <td>{{$employee->empId}}</td>
            <td>{{$employee->name}}</td>
            <td>{{$designations[$employee->designation]}}</td>
            <td>{{$employee->mobile}}</td>
            <td onclick="window.location.href='{{url('/')}}\/Admin/Employee/{{$employee->id}}\/edit'"><i class="fa fa-edit"></i></td>
            <td onclick="window.location.href='{{url('/')}}\/Admin/Employee/{{$employee->id}}\/destroy'"><i class="fa fa-trash-o"></i></td>
        </tr>
    @endforeach
    </tbody>
</table>

@endsection