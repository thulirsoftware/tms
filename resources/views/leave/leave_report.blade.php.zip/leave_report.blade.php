@extends('theme.default')

@section('content')
<div style="padding-top: 30px">
</div>
<a href="/Admin/Leave"><i class="fa fa-arrow-left fa-2x" aria-hidden="true"></i>
    </a>
<div style="text-align:center;font-size:25px;font-weight:bold;margin-top:-25px">
  Leave Report - {{ $month }}

</div>
<div style="padding-top: 10px">
</div>
<table class="table table-bordered table-hover" style="text-align:center;">
    <?php
        $i=1;
        ?>


<?php

    $employees = App\Employee::all();

?>
    <thead style="background-color: #d3ebc5;">
        <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Assigned Leave</th>
            <th>Taken Leave</th>
            <th>Available Leaves</th>
            <th>days to compensate</th>
            <th colspan="2">Add / Decrement<br> CASUAL LEAVE</th>
        </tr>
    </thead>
    <tbody>
@foreach ($employees as $employee)

<?php

$assignedLeave = App\EmployeesLeave::where('empId',$employee->id)->first();
$cl=$assignedLeave['el'];
$taken=$assignedLeave['taken'];
$available=$cl-$taken;
?>
        <tr>
            <td>{{ $employee->id }}</td>
            <td>{{ $employee->name }}</td>
            <td>{{ $assignedLeave['el'] }}</td>
            <td>{{ $assignedLeave['taken'] }}</td>
            <td>{{ $available }}</td>
            <td>{{ $assignedLeave['compensate'] }}</td>
            <td><i id="addLeave<?=$employee->id?>" onclick="return confirm('Add 1 CL ?') && addLeave({{$employee->id}})" class="fa fa-plus" style="font-size:25px;color:green"></i></td>
            <td><i id="decLeave<?=$employee->id?>" onclick="return confirm('Decrement 1 CL ?') && decLeave({{$employee->id}})" class="fa fa-minus" style="font-size:25px;color:green"></i></td>
        </tr>
@endforeach
    </tbody>
</table>


<script type="text/javascript">

function addLeave(empId) {

      $.ajaxSetup({
             headers: {
                  'X-CSRF-TOKEN': '{{csrf_token()}}'
             }
        });
   
        $.ajax({
             method: "POST",
             url: "/Ajax/addCL",
             data: { empId:empId }
             }).done(function(data){  
                console.log(data);    
                if(data.status==true)
                {
                    location.reload(true);
                }      
                else
                {
                    alert('Try Again!');
                    location.reload(true);
                } 
             }); 
   
}

function decLeave(empId) {

      $.ajaxSetup({
             headers: {
                  'X-CSRF-TOKEN': '{{csrf_token()}}'
             }
        });
   
        $.ajax({
             method: "POST",
             url: "/Ajax/decCL",
             data: { empId:empId }
             }).done(function(data){  
                console.log(data);    
                if(data.status==true)
                {
                    location.reload(true);
                }      
                else
                {
                    alert('Try Again!');
                    location.reload(true);
                } 
             }); 
   
}

</script>


@endsection